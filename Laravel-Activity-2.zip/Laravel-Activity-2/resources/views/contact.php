<!DOCTYPE HTML>
<html>

<head>
  <title>Website</title>

  <link rel="stylesheet" type="text/css" href="css/style.css" title="style" />
</head>

<body>
  <div id="main">
    <div id="header">
      <div id="logo">
        <div id="logo_text">
          <h1>WE ARE JAG</h1>
        </div>
      </div>
      <div id="menubar">
        <ul id="menu">
          <li class="selected">
          <a href="http://localhost:8000/home">HOME</a></li>
          <li><a href="http://localhost:8000/about">ABOUT US</a></li>
           <li><a href="http://localhost:8000/contact">CONTACT</a></li>
           <li><a href="http://localhost:8000/login">LOGIN</a></li>
           <li><a href="http://localhost:8000/register">REGISTER</a></li>
        </ul>
      </div>
    </div> 
    </div>
    </div>

    <style>

    .con{
        border: 2px solid white;
        background-color: #143d52;
        border-collapse: collapse;
        width: 30%;
        padding: 20px;
        font-weight: bold;
        font-family: Arial;
        margin-top: 5px;
        color: white;
      }

    </style>

  <center>
    <div class="con">

      <h1>CONTACTS</h1> <br><br>

      <p>
        Vi-Ann Q. Agbulos - 09307252373 <br><br>
        Tiffany Mae B. Gonzales - 09509244149 <br><br>
        Karla Mae D. Juliano - 09506194246
      </p>
      


    </div>

</center>
  

  </div>
</body>
</html>
