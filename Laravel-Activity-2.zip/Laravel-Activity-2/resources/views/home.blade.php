<!DOCTYPE HTML>
<html>

<head>
  <title>Website</title>

  <link rel="stylesheet" type="text/css" href="css/style.css" title="style" />
</head>

<body>
  <div id="main">
    <div id="header">
      <div id="logo">
        <div id="logo_text">
          <h1>WE ARE JAG</h1>
        </div>
      </div>
      <div id="menubar">
        <ul id="menu">
          <li class="selected">
          <a href="http://localhost:8000/home">HOME</a></li>
          <li><a href="http://localhost:8000/about">ABOUT US</a></li>
           <li><a href="http://localhost:8000/contact">CONTACT</a></li>
           <li><a href="http://localhost:8000/login">LOGIN</a></li>
           <li><a href="http://localhost:8000/register">REGISTER</a></li>
        </ul>
      </div>
    </div>
   </div>


   <style>

	.home {
  		border: 2px solid white;
  		background-color: #143d52;
  		border-collapse: collapse;
  		width: 80%;
  		padding: 20px;
  		margin-top: 5px;
  		color: white;
  	}

  	.footer {
  		position: fixed;
  		left: 0;
  		bottom: 0;
  		width: 100%;
  		background-color: #143d52;
  		color: white;
  		text-align: center;
	}
    </style>

	<center>

		<div class="home">
     
   	<h1>WELCOME TO OUR WEBSITE!</h1>

    <p style="font-size: 20px; color: white; margin-left: 20px;">Our group is reliable to all especially in activities that should be demonstrated without being underestimated by anyone. <br> all are leaders, nothing high and nothing less but just equal.</p>

    <p style="font-size: 20px">Team work is important to get the job done quickly.</p>

    <div style="padding-left:20px; padding-right: 20px; font-size: 20px">

  	<p>In this portfolio website we will show you some information about us and how important this subject to us.This activity is a great way for us to gain new knowledge and experience a different way of group work. As a student we need to be more competitive and have good teamwork skills. Working in a team is common in higher education. Group work can make the task easier and develop another skill. Our portfolio is a living and changing collection of records that reflects our accomplishments, skills, experiences, and attributes. It highlights and presents samples of some of our best work, along with life experiences, values and achievements.</p>
  
  	</div>
  	</div>
	</center>
  	


  <div class="footer"> BSIT 3 - BLOCK 5 <br> C265-C266 </div>



</body>
</html>