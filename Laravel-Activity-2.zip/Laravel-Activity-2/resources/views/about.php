<!DOCTYPE HTML>
<html>

<head>
  <title>Website</title>

  <link rel="stylesheet" type="text/css" href="css/style.css" title="style" />
</head>

<body>
  <div id="main">
    <div id="header">
      <div id="logo">
        <div id="logo_text">
          <h1>WE ARE JAG</h1>
        </div>
      </div>
      <div id="menubar">
        <ul id="menu">
          <li class="selected">
          <a href="http://localhost:8000/home">HOME</a></li>
          <li><a href="http://localhost:8000/about">ABOUT US</a></li>
           <li><a href="http://localhost:8000/contact">CONTACT</a></li>
           <li><a href="http://localhost:8000/login">LOGIN</a></li>
           <li><a href="http://localhost:8000/register">REGISTER</a></li>
        </ul>
      </div>
    </div> 
  </div>
</div>

    <style>

  h2{
        font-size: 30px;
        text-shadow: 5px 5px 3px black;
        font-family: Segoe UI;
        color: white;
  }

  h3{

        font-size: 15px;
        text-shadow: 5px 5px 3px black;
        font-family: Segoe UI;
        color: white;

  }

  img{
    border: 5px solid white;
    height: 200px;
    width: 200px;
    border-radius: 25px 25px 25px 25px;
  }

  p{
    font-family: Segoe UI;
    border: 5px solid white;
    width: 80%;
    font-size: 15px;
  }


  .about{
    border: 2px solid white;
    border-radius: 25px 25px 25px 25px;
    background-color: #143d52;
    border-collapse: collapse;
    width: 70%;
    font-weight: bold;
    margin-top: 5px;
    color: white;
  }
    </style>

     
     <center>

    <div class="about">

        <h2><b>ALL ABOUT US</b></h2> <br>
     
         
        <br> 
        <img src="../img/vi.jpg"> 
        <h3>Vi-Ann Q. Agbulos<br>(LEADER)</h3> <br>

         
     <center> 
        
          <p>I am Vi-Ann Q. Agbulos, resident of San Jose Riveside, Urdaneta City Pangasinan. I am 21 years of    age. My parents are Antonio M. Agbulos and Vivian Q. Agbulos.I have a sister her name is V-yen Agbulos.My hobbies are watching videos from facebook and youtube.I like layouting and editing pictures. I want to be a graphic artist and a business woman. And I am claiming it because of Law of Attraction.
          </p>
    </tr>

    </td>
    </center> 

    <br>

    <center>
        <img src="../img/tif.jpg"> 
        <h3>Tiffany Mae B. Gonzales<br>(MEMBER)</h3> 

         
        <br>
        
     <center> 

       <p>My name is Tiffany Mae Bagalay Gonzales, Im from Calle Garcia St. Poblacion, Urdaneta City Pangasinan. Im 20 years Old. I love playing Online games, Watching Vlogs on youtube, Watching Kdramas and so on.. so the thing I love doing so much became even more enjoyable. My Mother's name is Pia B. Gonzales and My Father's name is Ferdinand C. Gonzales, I have 3 siblings and they are Tom Philip, Kimberly Mae and Chelsea Mae Im the youngest of them all.<br><br>I am a College Student of Urdaneta City University, My course is Bachelor of Science in Information Technology. I study hard because my goal is to become a respected professional someday. Moreover, being a sociable person, I have many friends since I like to communicate with people and get to know new interesting individuals.</p>
  </tr>

    </td>
    </center> 

    <br>

    <center>
        <img src="../img/karla.jpg"> 
        <h3>Karla Mae D. Juliano<br>(MEMBER)</h3> 

         
        <br>
        
     <center> 
    <p>I am 21 years old, Karla Mae Juliano from land of "Chismosa" Sta. Barbara Pangasinan. I reflect a varied personality including ambition, and qualities of generosity and thoughtfulness. I encourage fighting for what you desire and believe in, and doing it through God because nothing great comes easy and with God everything is possible. <br>

    <br>I am the third children of Larry Juliano (my father) Regina Juliano (my mother), we have a five siblings in our family. My father are construction worker and my mother are house wife. <br>

    <br>I am a full-time student motivated by my love for learning and succeeding as I strive to become an outstanding and successful woman in todays society. I am studied in Urdaneta City University for the course Bachelor of Science and Information Technology Education and now I am incoming 3rd year. <br>

    <br>Through my passion for performing. I have a fanatical interest in pageantry from an infant growing up and so have participated in five pageants. Placing in the top five and top three in all five pageants while being rewarded the Best in Talent, I was crowned as 1st Runner Up when I am in High School. Someday I want to become a successful business woman as a professional programmer. <br><br>
  </tr>

    </td>
    </center> 
    </div>
  </div>
</body>
</html>
